# ICLOCS
Imperial College London Optimal Control Software (ICLOCS)

http://www.ee.ic.ac.uk/ICLOCS/

## Note for updating your problem from version 2 to run with version 2.5

We have recently introduced changes to the problem file (see myProblem.m in the template). 

To update your existing problem to work with version 2.5.1 onwards, please make the following changes:
* Update the codes for section "Get function handles and return to Main.m" with the ones in the new template
* Remove all codes below the divider

	%% Leave the following unchanged! %%
